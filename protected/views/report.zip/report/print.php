<style type="text/css">
    #header{
        display: none;
    }
</style>
werwer
<?php

?>