<?php
/* @var $this ReportController */
/* @var $model Cart */
/* @var $form CActiveForm */
/* @var $cat ReportController */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'product-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
	'method' => 'get',
	'action' => $this->createUrl('report/create') //,'/report/create']),
));
//print_r(CHtml::listData(Category::model()->findAll(),'id','Name'));
$typedata=array('day'=>'Day','week'=>'Week','month'=>'Month');

 ?>


	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->error($model,'time',array('class'=>'error_position')); ?>	
		<?php echo $form->labelEx($model,'Select Type'); ?>
		<?php echo $form->dropDownList($model,'time',$typedata,array(
                        'ajax' => array(
                            'type' => 'POST',
                            'url' => ReportController::createUrl('dynamicStates'),
                            'update' => '#Cart_'.'status',
							'data'=>'js:$(this).serialize()+"&hidden_state='.$model->status.'"',
                        ),'prompt'=>'Select Type',
                    )); ?>
		<?php echo $form->error($model,'time'); ?>
	</div>
	<div class="row">
	<?php // echo $form->label($model,'state',array('class'=>'control-label')); ?>
		<?php // echo CHtml::dropDownList('VkUsers[state]','', array(),array('prompt'=>'Select','id'=>'VkUsers_state'),array('class'=>'m-wrap large tooltips','data-original-title'=>'State'))); ?>
		<?php echo $form->error($model,'status',array('class'=>'error_position')); ?>		
        <?php echo $form->labelEx($model,'Date'); ?>
        <?php echo $form->dropDownList($model,'status',array(),array('prompt'=>'Select','id'=>'Cart_status'));?>
        <?php echo $form->error($model,'status'); ?>
    </div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Find'); ?>
	</div>

<?php $this->endWidget(); ?>
</div><!-- form -->
<?php
//print_r($model);
// $abc=[
//    'options'=>'{
//       "title": { "text": "Fruit Consumption" },
//       "xAxis": {
//          "categories": ['.rtrim($cat,",").']
//       },
//       "yAxis": {
//          "title": { "text": "Fruit eaten" }
//       },
//       "series": [
//          { "name": "Jane", "data": ['.rtrim($chartdata,",").'] }
//       ]
//    }'
// ];
// print_r($abc);
// $this->Widget('ext.highcharts.HighchartsWidget', [
//    'options'=>'{
//       "title": { "text": "Daily Chart" },
//       "xAxis": {
//          "categories": ['.rtrim($cat,",").']
//       },
//       "yAxis": {
//          "title": { "text": "Number" }
//       },
//       "series": [
//          { "name": "'.$_GET['Cart']['status'].'", "data": ['.rtrim($chartdata,",").'] }
//       ]
//    }'
// ]); 
// print_r($chartdata);

?>