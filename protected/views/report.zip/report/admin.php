<?php
/* @var $this CartController */
/* @var $model Cart */

$this->breadcrumbs=array(
	'reports'=>array('admin'),
	'Manage',
);

$this->menu=array(
	//array('label'=>'List Bills', 'url'=>array('index')),
	//array('label'=>'Create Cart', 'url'=>array('create')),
);

?>

<h1>Sales Reports</h1>


<!-- daily sale

today total sales

highest sales product
lowest sales product

daily weekly and monthly

-->

<?php  $this->renderPartial('_form', array('model'=>$model)); ?>
<?php 



if($cat!="" && $chartdata!=""){

$this->Widget('ext.highcharts.HighchartsWidget', [
   'options'=>'{
      "title": { "text": "Daily Chart" },
      "xAxis": {
         "categories": ['.rtrim($cat,",").']
      },
      "yAxis": {
         "title": { "text": "Number" }
      },
      "series": [
         { "name": "'.$catstatus.'", "data": ['.rtrim($chartdata,",").'] }
      ]
   }'
]); 
}

// query  select record by date
//SELECT cart.id, cart.time,DATE_FORMAT(cart.time, "%Y-%m-%d") as date,history.productId,sum(history.number) as hinumber FROM cart inner join history on cart.cartId=history.cartId where date('2017-10-11') GROUP BY history.productId

?>
